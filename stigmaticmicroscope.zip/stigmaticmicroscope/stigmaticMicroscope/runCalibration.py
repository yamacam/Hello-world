"""
This package uses an interactive GUI to toggle and confirm parameters for
stigmatic microscope flow tracking calibration.

The user locates a directory containing a z stack from the stigmatic
microscope. The GUI directs the user to input or modify key parameters for
z calibration.

Parameters to change:
    z step size
    intensityThreshold
    xspan, yspan,
    spline fit s parameter

The user can toggle which outputs to display:
    whole image
    ROI
    Row, column sums, spline fits, and FWHM plots
    Z calibration curve

When the user is satisfied, the user can store the parameter set into a
parameters file for future use. Plots may also be exported.
"""

import stigmaticMicroscope
from matplotlib import pyplot as plt
import os
import random
import scipy


# Display image
zFilePath= 'E:/201904 Mint CY/0805 zStack/Images/20degWetRollBack/'
# zFilePath = 'E:/Collagen alignment/Final Trials/Images/zCalibration/'
zFiles = [i for i in os.listdir(zFilePath) if i.endswith('.tif')]
# print(zFiles)


# Set parameters
calibration = stigmaticMicroscope.Calibration()
# Adjust z step size
calibration.stepSize = 200*20/360 # micron/rotation * deg/360

# Pick out randomized images to check parameters
spotChecks = random.sample(zFiles, 5)

def getParameter(parameterName, function):
    # Function to interact with the user and identify the parameters to use.
    pass

# Change intensity threshold
calibration.intensityThreshold = 100

# # Load a frame
# zFile = zFiles[30]
# frame = stigmaticMicroscope.Frame('{}{}'.format(zFilePath, zFile), calDat = calibration)

# # Check it
# frame.getContours()
# frame.showThreshold()


# """ Check that span is appropriate and check the spline fit """
# zFile = zFiles[40]
# frame = stigmaticMicroscope.Frame('{}{}'.format(zFilePath, zFile), calDat = calibration)
# frame.debugMode = True
# print(frame.getPositions(calZ=5))


# """ Track particles """
# particles = []
# for idx, zFile in enumerate(spotChecks):
#     print(idx, zFile)
#     frame = stigmaticMicroscope.Frame('{}{}'.format(zFilePath, zFile),
#                                       calDat = calibration)
#     positions = frame.getPositions(calZ=idx)
#     particles = stigmaticMicroscope.linkParticles(particles, positions, idx)

# for particle in particles:
#     particle.print_particles()


""" Check calibration curves """
particles = []
for idx, zFile in enumerate(zFiles):
    zPos = idx*calibration.stepSize
    frame = stigmaticMicroscope.Frame('{}{}'.format(zFilePath, zFile),
                                      calDat = calibration)
    positions = frame.getPositions(calZ=zPos)
    particles = stigmaticMicroscope.linkParticles(particles, positions, idx)

# for particle in particles:
#     print(particle.Positions)

# particle = particles[0]
# _, _, _, cal_z, cal_w, cal_h = zip(*particle.Positions)
# print(cal_z)
# print(cal_w)
# print(cal_h)

# Filter calibration particles
minParticleLength = 5
particles = [i for i in particles if len(i.Positions) > minParticleLength]

# Define a function to fit z, given w and h
errFindZ = lambda z, w, h: np.r_[
    w_z(z)-w,
    h_z(z)-h
]
def findZ(w, h):
    if w+h < 15:
        z0 = 0
    elif w>h+2:
        z0 = -100
    else:
        z0 = 100
    foundZ = scipy.optimize.least_squares(errFindZ, z0, args = (w, h))
    if foundZ.success:
        return foundZ.x[0]
    print('Misfit!')
    return np.NaN

# Plot calibration particles

from scipy.interpolate import UnivariateSpline
import numpy as np


plt.figure(num=None, figsize=(13, 5), dpi=80, facecolor='w', edgecolor='k')
cal_w = dict()
cal_h = dict()
for _, calParticle in enumerate(particles):
    _, _, _, p_z, p_w, p_h = zip(*calParticle.Positions)
    
    # Find most in-focus position
    _, zLoc_w = min((l, z) for (z, l) in enumerate(p_w))
    _, zLoc_h = min((l, z) for (z, l) in enumerate(p_h))
    zLoc = int((zLoc_h + zLoc_w)/2)
    # print(zLoc)
    # print(p_z[zLoc])
    # plt.plot(p_z, p_w, 'b-', p_z, p_h, 'r-')
    # plt.show()

    # Apply offset
    # print(type(list(p_z)), type(p_z[zLoc]))
    p_z = [int(i) for i in np.array(p_z) - p_z[zLoc]]
    
    for idz, valz in enumerate(p_z):
        if valz not in cal_w:
            # print('add new valz', idz)
            cal_w[valz] = [p_w[idz]]
            cal_h[valz] = [p_h[idz]]
        else:
            # print('Add second+ valz', idz)
            cal_w[valz].append(p_w[idz])
            cal_h[valz].append(p_h[idz])

# print(cal_w)
w_means = dict()
h_means = dict()
for z in cal_w.keys():
    w_means[z] = np.mean(cal_w.get(z))
    h_means[z] = np.mean(cal_h.get(z))

# print(w_means)
w_means = dict(sorted(w_means.items()))
h_means = dict(sorted(h_means.items()))
# print(w_means)

# print(list(w_means.keys()))
print('Fit w')
w_z = UnivariateSpline(list(w_means.keys()), list(w_means.values()),
                       s=len(w_means)*100)
print('Fit h')
h_z = UnivariateSpline(list(h_means.keys()), list(h_means.values()),
                       s=len(h_means)*100)



# Plot
plt.subplot(1,2,1)
position = np.linspace(min(w_means.keys()), max(w_means.keys()), 80)
plt.plot(position, w_z(position), 'r-', position, h_z(position),'b-')
plt.plot(list(w_means.keys()),
         list(w_means.values()),
         'ro')
plt.plot(list(h_means.keys()),
         list(h_means.values()),
         'bo')
for realz in cal_w.keys():
    plotw = cal_w.get(realz)
    plotz = [realz for i in plotw]
    ploth = cal_h.get(realz)
    plt.plot(plotz, plotw, 'r.', alpha=0.1)
    plt.plot(plotz, ploth, 'b.', alpha=0.1)

plt.xlabel('Z position ($\mu$m)')
plt.ylabel('Fit dimension (pixels)')
plt.title('Shape fitting')
plt.tick_params('both', bottom='off', top='off', right='off', left='off')
# plt.ylim(0,40)



plt.legend(('Width Fit', 'Height Fit', 'Mean Width', 'Mean Height',
            'Raw Width', 'Raw Height'), loc=9)
# plt.subplots_adjust(hspace=0.5)




# Test it
plt.subplot(1,2,2)
for realz in cal_w.keys():
    newzs = [findZ(w, h) for w, h in zip(
        cal_w.get(realz), cal_h.get(realz))]
    plotz = [realz for i in cal_w.get(realz)]
    plt.plot(plotz, newzs, 'ko', alpha=0.1)
    
#     
# found = []
# for i in range(len(cal_w)):
#     found.append(findZ(cal_w[i], cal_h[i]))
# plt.subplot(1,2,2)
# plt.plot(cal_pos, found, 'g.', cal_pos, cal_pos, 'k-')
plt.xlabel('Measured Z position ($\mu$m)')
plt.ylabel('Back-calculated Z position ($\mu$m)')
#plt.ylim(-220,230)
#plt.xlim(-220,230)
plt.title('Calibration check')
plt.tick_params('both', bottom='off', top='off', right='off', left='off')
#plt.savefig(trace_file_path+'20180720CY Calibration Figure.png')

plt.show()



