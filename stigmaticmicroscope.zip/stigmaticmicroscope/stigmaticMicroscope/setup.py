from distutils.core import setup

setup(
    name='stigmaticMicroscope',
    version='2.1dev',
    packages=['stigmaticMicroscope',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)