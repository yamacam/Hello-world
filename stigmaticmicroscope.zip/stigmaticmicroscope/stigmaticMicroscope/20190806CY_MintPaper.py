"""
20190806
Author: Cameron Yamanishi

Single-use code to perform flow tracking analysis on Mint's
rehydration data for the one-wash ELISA paper.
"""


import stigmaticMicroscope
from matplotlib import pyplot as plt
import os
import numpy as np
from scipy.stats import sem
from scipy.stats import f_oneway
from scipy import stats

# zFilePath = 'D:/201904 Mint CY/0805 zStack/Images/20degWetRollBackCropped/'
# # zFilePath = 'E:/Collagen alignment/Final Trials/Images/zCalibration/'
# zFiles = [i for i in os.listdir(zFilePath) if i.endswith('.tif')]
# # print(zFiles)


# # Set parameters
# calibration = stigmaticMicroscope.Calibration(filePath=zFilePath)
# # Adjust z step size
# calibration.stepSize = 200 * 20 / 360  # micron/rotation * deg/360
# calibration.intensityThreshold = 30

# # calibration.calibrate(plots=True)
# # plt.subplots_adjust(wspace=0.5)
# calibration.calibrate(plots=False)

# # """ Test trace flows on Mint data. """
# # testPath = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/\
# # 1. 9%PEG 9%DEX (19 July 2019)/1st/9%DEX 9%PEG (1)/'
# # calibration.minParticleLength = 50
# # particles = calibration.collectParticles(testPath)
# # writeFilePath = 'C:/users/cyamanishi3/desktop/'
# # writeFile = 'test.csv'
# # stigmaticMicroscope.writeReducedData(
# #     particles, writeFilePath,
# #     writeFile, minlength=50)

# """ Trace flows from April. """
# directory = 'D:/201904 Mint CY/'
# subDirs = [i for i in os.listdir(directory) if os.path.isdir(
#     '{}{}'.format(directory, i))]
# params = stigmaticMicroscope.LinkParameters()
# params.jumpDistSq = 2500
# for subDir in subDirs:
#     if '04' not in subDir:
#         print(subDir, 'skipped')
#         continue
#     print('searching', subDir)
#     thirdDirs = [i for i in os.listdir('{}/{}'.format(
#         directory, subDir)) if os.path.isdir(
#         '{}/{}/{}'.format(directory, subDir, i))]
#     for thirdDir in thirdDirs:
#         print('searching', thirdDir)
#         stacks = [i for i in os.listdir('{}/{}/{}'.format(
#             directory, subDir, thirdDir)) if os.path.isdir(
#             '{}/{}/{}/{}'.format(directory, subDir, thirdDir, i))]
#         for stack in stacks:
#             print('Found', stack)
#             local = '{}/{}/{}/'.format(
#                 directory, subDir, thirdDir)
#             stackName = os.path.splitext(stack)[0]
#             if os.path.exists('{}{}'.format(local, stackName)):
#                 if '002' in stackName:
#                     continue
#                 if 'ice' in stackName:
#                     continue
#                 print('Analyzing ', '{}{}'.format(local, stackName))
#                 particles = calibration.collectParticles(
#                     '{}{}/'.format(local, stackName),
#                     params=params)
#                 # print('Found {} particles', len(particles))
#                 # for particle in particles:
#                 #     particle.print_particles()
#                 stigmaticMicroscope.writeReducedData(
#                     particles,
#                     directory,
#                     '{}.csv'.format(stackName),
#                     minlength=50)
# # raise NameError
# # # Note that tStep = 2 for the April flat-bottom surface coating runs.


# """ Trace flows from July. """
# directory = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# subDirs = [i for i in os.listdir(directory) if os.path.isdir(
#     '{}{}'.format(directory, i))]
# params = stigmaticMicroscope.LinkParameters()
# params.jumpDistSq = 2500
# for subDir in subDirs:
#     thirdDirs = [i for i in os.listdir('{}/{}'.format(
#         directory, subDir)) if os.path.isdir(
#         '{}/{}/{}'.format(directory, subDir, i))]
#     for thirdDir in thirdDirs:
#         stacks = [i for i in os.listdir('{}/{}/{}'.format(
#             directory, subDir, thirdDir)) if i.endswith(
#             '.nd2')]
#         for stack in stacks:
#             local = '{}/{}/{}/'.format(
#                 directory, subDir, thirdDir)
#             stackName = os.path.splitext(stack)[0]
#             if os.path.exists('{}{}'.format(local, stackName)):
#                 print('dir found: ', local, stackName)
#                 particles = calibration.collectParticles(
#                     '{}{}/'.format(local, stackName),
#                     params=params)
#                 stigmaticMicroscope.writeReducedData(
#                     particles,
#                     directory,
#                     '{}longjumps.csv'.format(stackName),
#                     minlength=50)


# """ Plot flow traces April sets. """
# directory = 'D:/201904 Mint CY/'
# files = [i for i in os.listdir(directory) if i.endswith('.csv')]
# for file in files:
#     print(file)
#     stigmaticMicroscope.plotAndSave(directory, file, zmin=0, zmax=1400,
#                                     tStep=2, xdim=2, ydim=3, cdim=1,
#                                     nickname='XYT', xmin=0, xmax=1402)
#     plt.close()
#     stigmaticMicroscope.plotAndSave(directory, file, zmin=-200, zmax=200,
#                                     tStep=2, xdim=2, ydim=4, cdim=1,
#                                     nickname='', xmin=0, xmax=1402)
#     # plt.show()
#     plt.close()

# raise NameError

""" Plot flow traces. """
# directory = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# files = [i for i in os.listdir(directory) if i.endswith('.csv')]
# for file in files:
#     print(file)
#     stigmaticMicroscope.plotAndSave(directory, file, zmin=0, zmax=1400,
#                                     tStep=3, xdim=2, ydim=3, cdim=1,
#                                     nickname='XYT', xmin=0, xmax=1402)
#     plt.close()
#     stigmaticMicroscope.plotAndSave(directory, file, zmin=-200, zmax=200,
#                                     tStep=3, xdim=2, ydim=4, cdim=1,
#                                     nickname='', xmin=0, xmax=1402)
#     # plt.show()
#     plt.close()

""" Calculate speeds. """


def getCondition(file):
    DEXs = ['3%DEX', '5%DEX', '9%DEX', '10%DEX']
    PEGs = ['3%PEG', '5%PEG', '9%PEG', '10%PEG']
    for dex in DEXs:
        for peg in PEGs:
            if dex in file and peg in file:
                condition = '{} {}'.format(peg, dex)
            else:
                condition = file
    return condition


def calculateSpeeds(directory, tStep=1, duration=60, extension='.csv'):
    files = [i for i in os.listdir(directory) if i.endswith(extension)]
    speeds = {}
    for file in files:
        # print(file)
        print('include: ', file)
        data = stigmaticMicroscope.loadData(directory, file, tStep=tStep)

        """ Filter data to only first 15 min """
        data = data[data[:, 1] < duration * 60, :]
        data = stigmaticMicroscope.filterTraces(
            data, minTime=duration * 30, tStep=tStep)

        """ Calculate speed statistics across all replicates. """
        # data = stigmaticMicroscope.filterTraces(data, 3000, tStep=3)
        if data is not None:
            condition = getCondition(file)

            for trace in stigmaticMicroscope.getSpeeds(data, tStep=3):
                mean = np.mean(trace['Speed (\mum/sec)'])
                try:
                    speeds[condition] = np.append(speeds[condition], mean)
                    print('added speed', mean)
                except KeyError:
                    print('first speed', mean)
                    speeds[condition] = [mean]
            for trace in stigmaticMicroscope.getSpeeds(data, tStep=tStep):
                mean = np.mean(trace['Speed (\mum/sec)'])
                try:
                    speeds[condition] = np.append(speeds[condition], mean)
                    print('added speed', mean)
                except KeyError:
                    print('first speed', mean)
                    speeds[condition] = [mean]

    return speeds

# def getCondition(file):
#     DEXs = ['3%DEX', '5%DEX', '9%DEX']
#     PEGs = ['3%PEG', '5%PEG', '9%PEG']
#     for dex in DEXs:
#         for peg in PEGs:
#             if dex in file and peg in file:
#                 condition = '{} {}'.format(peg, dex)
#     return condition


""" Calculate speeds for April traces. """
directory = 'D:/201904 Mint CY/'
tStep = 2
duration = 60
speeds = calculateSpeeds(directory, tStep, duration)
# Note: E:/ on the shu lab desktop. D:/ on the surfacepro

""" Calculate speeds for old traces. """
# directory = 'D:/Rehydration traces/Simple/'
# speeds = calculateSpeeds(directory, tStep=5, duration=15, extension='.tif')
# # Doesn't quite work. The format of the particle .csv may be different

""" old method for getting July traces. """
# # directory = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# directory = 'D:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# # Note: E:/ on the shu lab desktop. D:/ on the surfacepro
# files = [i for i in os.listdir(directory) if i.endswith('.csv')]
# speeds = {}
# for file in files:
#     # print(file)
#     if 'longjumps' not in file:
#         print('skip: ', file)
#         continue
#     print('include: ', file)
#     data = stigmaticMicroscope.loadData(directory, file, tStep=3)

#     """ Filter data to only first 15 min """
#     data = data[data[:, 1] < 15 * 60, :]
#     data = stigmaticMicroscope.filterTraces(data, minTime=3000 / 4, tStep=3)

#     """ Calculate speed statistics across all replicates. """
#     # data = stigmaticMicroscope.filterTraces(data, 3000, tStep=3)
#     if data is not None:
#         condition = getCondition(file)
#         for trace in stigmaticMicroscope.getSpeeds(data, tStep=3):
#             mean = np.mean(trace['Speed (\mum/sec)'])
#             try:
#                 speeds[condition] = np.append(speeds[condition], mean)
#                 print('added speed', mean)
#             except KeyError:
#                 print('first speed', mean)
#                 speeds[condition] = [mean]

# data = stigmaticMicroscope.filterTraces(data, 1000, tStep=3)
# if data is not None:
#     allSpeeds = stigmaticMicroscope.collectAllSpeeds(data, tStep=3)
#     condition = getCondition(file)
#     speeds[condition] = allSpeeds

""" Plot Z over time """
# data = stigmaticMicroscope.loadData(directory, file, tStep=3)
# plt.figure()
# for trace in stigmaticMicroscope.getIndTrace(data):
#     plt.plot(trace[:, 1], trace[:, 4])
# plt.title(file)
# plt.xlim(0, 3600)
# plt.ylim(-200, 200)
# plt.ylabel('Z (micron)')
# plt.xlabel('Time (sec)')
# plt.savefig('{}{}Zplot.png'.format(directory, file))
# plt.close()

""" Calculate averall average speed. """
# allSpeeds = stigmaticMicroscope.collectAllSpeeds(data, tStep=3)
# meanSpeed = np.mean(allSpeeds)
# print(int(meanSpeed * 60), 'micron/min', file)

""" Filter data and check distances traveled. """
# data = filterTraces(data, 1000, tStep=3)
# if data is not None:
#     dist = integrateSpeeds(data, tStep=3)
#     print(dist)
#     distances[file] = dist

""" Check speeds. """
# speeds = stigmaticMicroscope.getSpeeds(data, tStep=3)
# for trace in speeds:
#     # for dim in [2, 3, 4]:
#     #     plt.plot(trace[1], trace[dim])
#     plt.plot(trace[1], trace['Speed (\mum/sec)'])
# plt.title('Mean speed: {}\nCondition: {}'.format(meanSpeed, file))
# plt.ylabel('Speed (micron/sec)')
# plt.xlabel('Time (sec)')
# plt.ylim(-5, 5)
# plt.xlim(0, 3600)
# # plt.show()
# plt.savefig('{}15 min speeds/{} 15 min Speeds.png'.format(directory, file))
# plt.close()

""" Check Lowess. """
# smooth_xs = applyLowess(data)
# for dim in [2, 3, 4]:
#     plt.plot(smooth_xs[:, 1], smooth_xs[:, dim])
# plt.figure()
# print(distances)

""" calculate mean speeds. """
meanSpeeds = {}
devSpeeds = {}
semSpeeds = {}
confidenceE = {}
print('Calculate means')


def mean_confidence_interval(data, confidence=0.95):
    a = 1.0 * np.array(data)
    n = len(a)
    m, se = np.mean(a), sem(a)
    h = se * stats.t.ppf((1 + confidence) / 2., n - 1)
    return h


for condition in speeds.keys():
    meanSpeeds[condition] = 60 * np.mean(speeds[condition])  # micron/min
    devSpeeds[condition] = 60 * np.std(speeds[condition])
    semSpeeds[condition] = 60 * sem(speeds[condition])
    confidenceE[condition] = 60 * mean_confidence_interval(speeds[condition])

print('means')
for item in meanSpeeds.items():
    print(item)

print('std dev')
for item in devSpeeds.items():
    print(item)

print('sem')
for item in semSpeeds.items():
    print(item)

print('confidence E')
for item in confidenceE:
    print(item)

con = list(speeds.keys())
print(con)
F, p = f_oneway(
    speeds[con[0]],
    speeds[con[1]],
    speeds[con[2]])
print('F: ', F)
print('p: ', p)

# Plot meanSpeeds
print('Plotting...')
plt.bar(
    np.linspace(1, len(meanSpeeds), len(meanSpeeds)),
    list(meanSpeeds.values()),
    tick_label=list(meanSpeeds.keys()), color='k',
    yerr=list(confidenceE.values()))
plt.title('Mean convective speed over first {} min'.format(duration))
plt.ylim(0, 60)
plt.ylabel('Speed (micron/min) +/- 95% Confidence Interval')
plt.show()
