"""
20190810
Author: Cameron Yamanishi

Single-use code to perform flow tracking analysis on Alec's
ATPS collagen gel convection.
"""


import stigmaticMicroscope
from matplotlib import pyplot as plt
import os
import numpy as np
from scipy.stats import sem
from scipy.stats import f_oneway
from scipy import stats

zFilePath = 'D:/Collagen alignment/Final Trials/Images/zCalibration/'
# zFiles = [i for i in os.listdir(zFilePath) if i.endswith('.tif')]
# print(zFiles)


# # Set parameters
# calibration = stigmaticMicroscope.Calibration(filePath=zFilePath)
# # Adjust z step size
# calibration.stepSize = 200 * 10 / 360  # micron/rotation * deg/360

# threshold = 80
# span = 15
# calibration.minParticleLength = 30
# calibration.intensityThreshold = threshold
# calibration.span = span

# # calibration.calibrate(plots=True)
# # raise NameError
# print('thresh {}, span {}'.format(threshold, span))
# calibration.calibrate(plots=False)
# # plt.subplots_adjust(wspace=0.5)

# calibration.minParticleLength = 10


# directory = 'D:/Collagen alignment/Final Trials/Images/'
# subDirs = [i for i in os.listdir(directory) if os.path.isdir(
#     '{}'.format(directory, i))]
# params = stigmaticMicroscope.LinkParameters()
# params.maxAge = 10
# params.jumpDistSq = 900
# for stack in subDirs:
#     stackName = os.path.splitext(stack)[0]
#     if os.path.exists('{}{}'.format(directory, stackName)):
#         if 'Col' not in stackName:
#             continue
#         print('dir found: ', directory, stackName)
#         particles = calibration.collectParticles(
#             '{}{}/'.format(directory, stackName),
#             params=params)
#         stigmaticMicroscope.writeReducedData(
#             particles,
#             directory,
#             '{} t{} s{}.csv'.format(stackName, threshold, span),
#             minlength=50)
# # except ValueError:
# #     continue


    # raise NameError
""" Plot flow traces. """
directory = 'D:/Collagen alignment/Final Trials/Images/'
files = [i for i in os.listdir(directory) if i.endswith('.csv')]
for file in files:
    print(file)
    if '6%_PEG_3%_DEX_Col_8009' in file:
        print('skip 6%_PEG_3%_DEX_Col_8009')
        continue
    elif 'zCalibration' in file:
        print('Skip zCalibration')
        continue
    stigmaticMicroscope.plotAndSave(directory, file, zmin=0, zmax=1400,
                                    tStep=3, xdim=2, ydim=3, cdim=1,
                                    nickname='XYT', xmin=0, xmax=1402,
                                    tmax=500)
    plt.close()
    stigmaticMicroscope.plotAndSave(directory, file, zmin=-200, zmax=200,
                                    tStep=3, xdim=2, ydim=4, cdim=1,
                                    nickname='XZT', xmin=0, xmax=1400,
                                    tmax=500)
    # plt.show()
    plt.close()

""" Calculate speeds. """


# def getCondition(file):
#     DEXs = ['3%DEX', '5%DEX', '9%DEX']
#     PEGs = ['3%PEG', '5%PEG', '9%PEG']
#     for dex in DEXs:
#         for peg in PEGs:
#             if dex in file and peg in file:
#                 condition = '{} {}'.format(peg, dex)
#     return condition


# # directory = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# directory = 'D:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
# # Note: E:/ on the shu lab desktop. D:/ on the surfacepro
# files = [i for i in os.listdir(directory) if i.endswith('.csv')]
# speeds = {}
# for file in files:
#     # print(file)
#     if 'longjumps' not in file:
#         print('skip: ', file)
#         continue
#     print('include: ', file)
#     data = stigmaticMicroscope.loadData(directory, file, tStep=3)

#     """ Filter data to only first 15 min """
#     data = data[data[:, 1] < 15 * 60, :]
#     data = stigmaticMicroscope.filterTraces(data, minTime=3000 / 4, tStep=3)

#     """ Calculate speed statistics across all replicates. """
#     # data = stigmaticMicroscope.filterTraces(data, 3000, tStep=3)
#     if data is not None:
#         condition = getCondition(file)
#         for trace in stigmaticMicroscope.getSpeeds(data, tStep=3):
#             mean = np.mean(trace['Speed (\mum/sec)'])
#             try:
#                 speeds[condition] = np.append(speeds[condition], mean)
#                 print('added speed', mean)
#             except KeyError:
#                 print('first speed', mean)
#                 speeds[condition] = [mean]

#     # data = stigmaticMicroscope.filterTraces(data, 1000, tStep=3)
#     # if data is not None:
#     #     allSpeeds = stigmaticMicroscope.collectAllSpeeds(data, tStep=3)
#     #     condition = getCondition(file)
#     #     speeds[condition] = allSpeeds

#     """ Plot Z over time """
#     # data = stigmaticMicroscope.loadData(directory, file, tStep=3)
#     # plt.figure()
#     # for trace in stigmaticMicroscope.getIndTrace(data):
#     #     plt.plot(trace[:, 1], trace[:, 4])
#     # plt.title(file)
#     # plt.xlim(0, 3600)
#     # plt.ylim(-200, 200)
#     # plt.ylabel('Z (micron)')
#     # plt.xlabel('Time (sec)')
#     # plt.savefig('{}{}Zplot.png'.format(directory, file))
#     # plt.close()



#     """ Calculate averall average speed. """
#     # allSpeeds = stigmaticMicroscope.collectAllSpeeds(data, tStep=3)
#     # meanSpeed = np.mean(allSpeeds)
#     # print(int(meanSpeed * 60), 'micron/min', file)

#     """ Filter data and check distances traveled. """
#     # data = filterTraces(data, 1000, tStep=3)
#     # if data is not None:
#     #     dist = integrateSpeeds(data, tStep=3)
#     #     print(dist)
#     #     distances[file] = dist

#     """ Check speeds. """
#     # speeds = stigmaticMicroscope.getSpeeds(data, tStep=3)
#     # for trace in speeds:
#     #     # for dim in [2, 3, 4]:
#     #     #     plt.plot(trace[1], trace[dim])
#     #     plt.plot(trace[1], trace['Speed (\mum/sec)'])
#     # plt.title('Mean speed: {}\nCondition: {}'.format(meanSpeed, file))
#     # plt.ylabel('Speed (micron/sec)')
#     # plt.xlabel('Time (sec)')
#     # plt.ylim(-5, 5)
#     # plt.xlim(0, 3600)
#     # # plt.show()
#     # plt.savefig('{}15 min speeds/{} 15 min Speeds.png'.format(directory, file))
#     # plt.close()

#     """ Check Lowess. """
#     # smooth_xs = applyLowess(data)
#     # for dim in [2, 3, 4]:
#     #     plt.plot(smooth_xs[:, 1], smooth_xs[:, dim])
#     # plt.figure()
# # print(distances)

# """ calculate mean speeds. """
# meanSpeeds = {}
# devSpeeds = {}
# semSpeeds = {}
# confidenceE = {}
# print('Calculate means')


# def mean_confidence_interval(data, confidence=0.95):
#     a = 1.0 * np.array(data)
#     n = len(a)
#     m, se = np.mean(a), sem(a)
#     h = se * stats.t.ppf((1 + confidence) / 2., n - 1)
#     return h


# for condition in speeds.keys():
#     meanSpeeds[condition] = 60 * np.mean(speeds[condition])  # micron/min
#     devSpeeds[condition] = 60 * np.std(speeds[condition])
#     semSpeeds[condition] = 60 * sem(speeds[condition])
#     confidenceE[condition] = 60 * mean_confidence_interval(speeds[condition])

# print('means')
# for item in meanSpeeds.items():
#     print(item)

# print('std dev')
# for item in devSpeeds.items():
#     print(item)

# print('sem')
# for item in semSpeeds.items():
#     print(item)

# print('confidence E')
# for item in confidenceE:
#     print(item)

# con = list(speeds.keys())
# print(con)
# F, p = f_oneway(
#     speeds[con[0]],
#     speeds[con[1]],
#     speeds[con[2]],
#     speeds[con[3]],
#     speeds[con[4]],
#     speeds[con[5]],
#     speeds[con[6]])
# print('F: ', F)
# print('p: ', p)

# # Plot meanSpeeds
# print('Plotting...')
# plt.bar(
#     np.linspace(1, len(meanSpeeds), len(meanSpeeds)),
#     list(meanSpeeds.values()),
#     tick_label=list(meanSpeeds.keys()), color='k',
#     yerr=list(confidenceE.values()))
# plt.title('Mean convective speed over first 15 min')
# plt.ylim(0,60)
# plt.ylabel('Speed (micron/min) +/- 95% Confidence Interval')
# plt.show()
