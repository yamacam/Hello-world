# Run image analysis
"""
Created on Thurs 2019 April 25 17:02

Perform image processing on files for the Aaron Enten collaboration.
Expect this to be a similar process that should be applicable to future projects.

Source data is .nd2 files from the stigmatic microscope.
Z calibration images collected by Cameron Yamanishi.
Filter flow trace images collect by Cameron Yamanishi and Sonia Cillero.

Output is a summary figure depicting a series of bead locations at successive backflushes.
Output also includes calibration and quality control figures.
"""


