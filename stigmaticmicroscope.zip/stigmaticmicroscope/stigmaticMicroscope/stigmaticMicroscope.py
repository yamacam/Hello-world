"""
20190806
Author: Cameron Yamanishi
Description:
This script contains classes and functions necessary for calibration and flow
tracking using the stigmatic microscope in the Takayama Lab at Georgia Tech.
"""

import cv2
from matplotlib import pyplot as plt
from matplotlib import colors
from matplotlib import cm
import numpy as np
import scipy.optimize
from scipy.interpolate import UnivariateSpline
from statsmodels.nonparametric.smoothers_lowess import lowess
import copy
# import time
# import csv
import os
# import plotly.plotly
# from plotly.graph_objs import *


class Particle(object):
    def __init__(self, ID, x, y, z, w, h, t):
        self.ID = ID
        self.Positions = []
        self.Positions.append([t, x, y, z, w, h])
        self.Age = 0

    def addpos(self, x, y, z, t, w, h):
        self.Positions.append([t, x, y, z, w, h])

    def getpos(self):
        return (self.Positions[-1][1], self.Positions[-1][2])

    def getid(self):
        return (self.ID)

    def print_particles(self):
        print("ID:", self.ID, "\n")
        print("Positions:", self.Positions, "\n")

    def print_position(self, i):
        print(self.Positions[i])


class Frame(object):
    """ Frame class contains functions to perform analyses on individual
    images.
    """

    def __init__(self, filePath, calDat=None):
        # Specify an individual frame by its directory location.
        self.filePath = filePath
        if calDat is None:
            self.calDat = Calibration()
        else:
            self.calDat = calDat
        self.img = img = cv2.imread(filePath, 0)
        if type(img) != np.ndarray:
            raise ValueError(
                'Image file missing or corrupted. {}'.format(filePath))
        self.dimensions = [len(img[0]), len(img)]
        self.debugMode = False

    def getContours(self):
        # Get particles from an individual image
        ret, self.thresh = cv2.threshold(
            self.img, self.calDat.intensityThreshold, 255, 0
        )
        # plt.imshow(thresh)
        # Get the threshold of the image
        # print(cv2.findContours(self.thresh, 1, 2))
        try:
            _, contours, hierarchy = cv2.findContours(self.thresh, 1, 2)
        except ValueError:
            contours, hierarchy = cv2.findContours(self.thresh, 1, 2)
        # Get the contours from the thresholded image
        return contours

    def showThreshold(self):
        plt.subplot(1, 2, 1)
        plt.imshow(self.img, cmap='gray')
        plt.title("{}".format(self.filePath[-10:]))
        plt.subplot(1, 2, 2)
        plt.imshow(self.thresh)
        plt.show()
        return

    def findxy(self, cnt):
        (x, y), _ = cv2.minEnclosingCircle(cnt)
        # print("Circle center: x {}, y {}".format(x, y))
        return [x, y]

    def filterContours(self, contours, minArea=25):
        # tempContour = contours[0]
        ok_contours = [i for i in contours if cv2.contourArea(i) > minArea]
        return ok_contours

    def fitFWHM(self, roi, ax):
        # Crop around a found particle and run a 2D Gaussian fit
        # Take in a center position and source image
        tots = np.sum(roi, axis=ax)
        pixel_arr = np.linspace(0, len(tots) - 1, len(tots))
        base = tots - np.min(tots)
        spline = UnivariateSpline(
            pixel_arr, base - np.percentile(base, 95) / 2, s=1e5)
        roots = spline.roots()

        # Show debug plots
        if len(roots) != 2:
            if len(roots) is 1:
                return 0
            if len(roots) < 1:
                # print('No spline roots')
                return np.NaN
            else:
                fwhm = np.max(roots) - roots[0]
        else:
            fwhm = roots[1] - roots[0]

        if self.debugMode:
            pixel_arr_hd = np.linspace(0, len(tots) - 1, 1000)
            plt.plot(pixel_arr, base, '-')
            plt.plot(pixel_arr_hd, spline(pixel_arr_hd), 'r-')
            plt.tick_params('both', bottom='off', top='off',
                            right='off', left='off')
            plt.xlabel('Pixel number')
            plt.legend(('Intensity', 'Spline fit'))
            plt.plot(pixel_arr_hd, np.zeros(len(pixel_arr_hd)), 'k-')
        return fwhm

    def fit2D(self, x, y):
        # Crop the image around the particle
        span = self.calDat.span
        roi = self.img[np.int(y - span):np.int(y + span),
                       np.int(x - span):np.int(x + span)]
        if self.debugMode:
            plt.figure()
            # plt.subplot(1, 3, 1)
            plt.title('Region of interest intensity heatmap')
            plt.imshow(roi)
            plt.tick_params('both', bottom='off', top='off',
                            right='off', left='off')
            # plt.subplot(1, 3, 2)
            plt.figure()
        w = self.fitFWHM(roi, 0)
        if self.debugMode:
            try:
                plt.title('x fit {}'.format(int(w)))
            except ValueError:
                print('fit2D plot ValueError {}'.format(self.filePath))

        if self.debugMode:
            plt.figure()
            # plt.subplot(1, 3, 3)
        h = self.fitFWHM(roi, 1)
        if self.debugMode:
            try:
                plt.title('y fit {}'.format(int(h)))
            except ValueError:
                print('fit2D plot ValueError {}'.format(self.filePath))
            plt.show()
        return [w, h]

    def getPositions(self, calZ=None):
        contours = self.getContours()
        span = self.calDat.span
        positions = []

        # For each contour check to see if it is a good contour
        # and meets the area requirement.
        ok_contours = self.filterContours(contours)
        for cnt in ok_contours:
            x, y = self.findxy(cnt)
            # print('x, y', x, y)
            if(x > span and y > span and x < self.dimensions[
               0] and y < self.dimensions[1]):
                # Collect its location
                w, h = self.fit2D(int(x), int(y))
                if (np.isnan(w + h)):
                    continue
                if calZ is None:
                    # if (0 < w < maxDim and 0 < h < maxDim):
                    z = self.calDat.findZ(w, h)
                    # print('z', z)
                    if (np.isnan(z)):
                        continue
                    positions.append([x, y, z, w, h])
                else:
                    positions.append([x, y, calZ, w, h])
        return positions


class Calibration(object):
    def __init__(self, name='Default', filePath=None):
        self.name = name
        self.w = []
        self.h = []
        self.z = []
        self.sFactor = 1
        self.span = 40
        self.intensityThreshold = 15
        self.stepSize = 5.55
        # Note that 360 deg on fine focus for TS100 is 200 micron.
        self.minContourSize = 25
        self.minParticleLength = 5
        self.filePath = filePath

    def addshape(self, w, h, z):
        self.w.append(w)
        self.h.append(h)
        self.z.append(z)

    def fitSplines(self):
        self.w_z = UnivariateSpline(
            list(self.w_means.keys()),
            list(self.w_means.values()),
            s=len(self.w_means) * self.sFactor)
        self.h_z = UnivariateSpline(
            list(self.h_means.keys()),
            list(self.h_means.values()),
            s=len(self.h_means) * self.sFactor)

    def errFindZ(self, z, w, h):
        return np.r_[self.w_z(z) - w, self.h_z(z) - h]

    def findZ(self, w, h):
        if w + h < 15:
            z0 = 0
        elif w > h + 2:
            z0 = -100
        else:
            z0 = 100
        foundZ = scipy.optimize.least_squares(self.errFindZ, z0, args=(w, h))
        if foundZ.success:
            return foundZ.x[0]
        print('Misfit!')
        return np.NaN

    def getTIFs(self, filePath=None):
        if filePath is None:
            try:
                files = [i for i in os.listdir(self.filePath) if i.endswith(
                    '.tif')]
            except FileNotFoundError:
                print('Warning: FileNotFoundError')
                return None
        else:
            try:
                files = [i for i in os.listdir(filePath) if i.endswith(
                    '.tif')]
            except FileNotFoundError:
                print('Warning: FileNotFoundError')
                return None
        return files

    def collectCalPositions(self, filePath=None, plots=True):
        files = self.getTIFs(filePath)
        self.particles = []
        for idx, f in enumerate(files):
            zPos = idx * self.stepSize
            frame = Frame('{}{}'.format(self.filePath, f), calDat=self)
            if idx % 20 == 0 and plots:
                frame.debugMode = True
            else:
                frame.debugMode = False
            self.positions = frame.getPositions(calZ=zPos)
            self.particles = linkParticles(
                self.particles, self.positions, idx)
        return

    def collectParticles(self, filePath, params=None):
        files = self.getTIFs(filePath)
        particles = []
        for t, f in enumerate(files):
            frame = Frame('{}/{}'.format(filePath, f), calDat=self)
            positions = frame.getPositions()
            particles = linkParticles(particles, positions, t, params)
            # Note that t is in frame numbers, not seconds.
        return particles

    def filterParticles(self):
        self.particles = [i for i in self.particles if len(
            i.Positions) > self.minParticleLength]
        return

    def correctOffsets(self):
        cal_w = dict()
        cal_h = dict()
        for calParticle in self.particles:
            # Read particle parameters
            _, _, _, p_z, p_w, p_h = zip(*calParticle.Positions)

            # Find most in-focus position
            _, zLoc_w = min((l, z) for (z, l) in enumerate(p_w))
            _, zLoc_h = min((l, z) for (z, l) in enumerate(p_h))
            zLoc = int((zLoc_h + zLoc_w) / 2)
            # Note that int() corrects for last digit rounding error,
            # but could be too aggressive with small step size.
            # print(zLoc)
            # print(p_z[zLoc])
            # plt.plot(p_z, p_w, 'b-', p_z, p_h, 'r-')
            # plt.show()

            # Apply offset
            # print(type(list(p_z)), type(p_z[zLoc]))
            p_z = [int(i) for i in np.array(p_z) - p_z[zLoc]]

            # Collect offset parameters into dicts.
            for idz, valz in enumerate(p_z):
                if valz not in cal_w:
                    # print('add new valz', idz)
                    cal_w[valz] = [p_w[idz]]
                    cal_h[valz] = [p_h[idz]]
                else:
                    # print('Add second+ valz', idz)
                    cal_w[valz].append(p_w[idz])
                    cal_h[valz].append(p_h[idz])
        self.cal_w = cal_w
        self.cal_h = cal_h

    def findCalMeans(self):
        self.w_means = dict()
        self.h_means = dict()
        for z in self.cal_w.keys():
            self.w_means[z] = np.mean(self.cal_w.get(z))
            self.h_means[z] = np.mean(self.cal_h.get(z))
            # Note that cal_w and cal_h should share the same z keys.
        # Sort means
        self.w_means = dict(sorted(self.w_means.items()))
        self.h_means = dict(sorted(self.h_means.items()))

    def plotCalibration(self):
        plt.subplot(1, 2, 1)
        position = np.linspace(min(self.w_means.keys()), max(
            self.w_means.keys()), 80)
        plt.plot(
            position, self.w_z(position), 'r-', position,
            self.h_z(position), 'b-')
        plt.plot(
            list(self.w_means.keys()),
            list(self.w_means.values()),
            'ro')
        plt.plot(
            list(self.h_means.keys()),
            list(self.h_means.values()),
            'bo')
        for realz in self.cal_w.keys():
            plotw = self.cal_w.get(realz)
            plotz = [realz for i in plotw]
            ploth = self.cal_h.get(realz)
            plt.plot(plotz, plotw, 'r.', alpha=0.1)
            plt.plot(plotz, ploth, 'b.', alpha=0.1)

        plt.xlabel('Z position ($\mu$m)')
        plt.ylabel('Fit dimension (pixels)')
        plt.title('Shape fitting')
        plt.tick_params('both', bottom='off', top='off',
                        right='off', left='off')
        # plt.ylim(0,40)

        plt.legend(('Width Fit', 'Height Fit', 'Mean Width', 'Mean Height',
                    'Raw Width', 'Raw Height'), loc=9)
        # plt.subplots_adjust(hspace=0.5)

        # Test it
        plt.subplot(1, 2, 2)
        for realz in self.cal_w.keys():
            newzs = [self.findZ(w, h) for w, h in zip(
                self.cal_w.get(realz), self.cal_h.get(realz))]
            plotz = [realz for i in self.cal_w.get(realz)]
            plt.plot(plotz, newzs, 'ko', alpha=0.1)

        #
        # found = []
        # for i in range(len(cal_w)):
        #     found.append(findZ(cal_w[i], cal_h[i]))
        # plt.subplot(1,2,2)
        # plt.plot(cal_pos, found, 'g.', cal_pos, cal_pos, 'k-')
        plt.xlabel('Measured Z position ($\mu$m)')
        plt.ylabel('Back-calculated Z position ($\mu$m)')
        # plt.ylim(-220,230)
        # plt.xlim(-220,230)
        plt.title('Calibration check')
        plt.tick_params('both', bottom='off', top='off',
                        right='off', left='off')
        # plt.savefig(trace_file_path+'20180720CY Calibration Figure.png')

        plt.show()

    def calibrate(self, plots=True):
        self.collectCalPositions(plots=plots)
        self.filterParticles()
        self.correctOffsets()
        self.findCalMeans()
        # try:
        self.fitSplines()
        # except dfitpack.error:
        # self.plotCalibration()
        if plots:
            self.plotCalibration()


class LinkParameters(object):
    def __init__(self, name='Default'):
        self.name = name
        self.maxAge = 5
        self.x_scale = 0.67  # px per micron
        self.y_scale = 0.63
        self.jumpDistSq = 400


def linkParticles(particles, positions, t, params=None):
    matchedPositions = []
    # remainingPositions = []
    if params is None:
        params = LinkParameters()

    # For every existing object test it against the current found objects.
    # "Have object, where did it go?"
    for particle in particles:
        if particle.Age < params.maxAge:
            (dt, dx, dy, dz, _, _) = particle.Positions[-1]
            # did = particle.ID
            # print('old particle: ', did, int(dt), int(dx), int(dy), int(dz))

            # Find the closest
            distArray = []
            for idx, pos in enumerate(positions):
                dist2 = ((dx - pos[0]) / params.x_scale)**2 + ((
                    dy - pos[1]) / params.y_scale)**2 + (dz - pos[2])**2
                distArray.append(dist2)
            # Sort the array according to distance
            sorteddata = sorted(zip(distArray, positions),
                                key=lambda x: x[0], reverse=False)

            if sorteddata != []:
                # Assign it
                # find the nth closest contour [n-1][1], in this case 1
                closestcontour = sorteddata[0][1]
                closestdist = sorteddata[0][0]
                # print('contour: ', closestcontour)
                # print('index: ', closestdist)
                if closestdist < params.jumpDistSq:
                    particle.Positions.append([t, *closestcontour])
                    matchedPositions.append(closestcontour)
                    # find closest contour in ok_contours and delete it

                    for idx, i in enumerate(positions):
                        if i == closestcontour:
                            positions.pop(idx)
                            # print('found '+str(idx))
                    particle.Age = 0
                    continue
            particle.Age = particle.Age + 1
    remaining_contours = copy.deepcopy(positions)
    pop_count = 0
    # print("ok_contours: ",ok_contours)
    for idi, i in enumerate(positions):
        # Identify matched contours and remove them
        found = 0
        for idj, j in enumerate(matchedPositions):
            if i == j:
                found = 1
        if found == 1:
            remaining_contours.pop(idi - pop_count)
            pop_count = pop_count + 1
    for remaining in remaining_contours:
        num_particles = len(particles) + 1
        particles.append(Particle(num_particles, *remaining, t))
    return particles


def writeReducedData(particles, trace_file_path, trace_file_name,
                     minlength=500):
    Ages = []
    Reduced_data = np.empty([1, 7])
    Temp_data = np.empty([1, 4])
    Hit_count = 0
    if len(particles) is 0:
        return 0
    for idx, particle in enumerate(particles):
        # print(idx)
        Temp_data = np.asarray(particle.Positions)
        length = len(Temp_data)
        # print(length)
        Ages.append(length)
        if length > minlength:
            id_array = np.empty([length, 1])
            id_array.fill(particle.ID)
            Temp_data = np.concatenate((id_array, Temp_data), axis=1)
            Reduced_data = np.concatenate((Reduced_data, Temp_data), axis=0)
            Hit_count = Hit_count + 1
    Reduced_data = np.delete(Reduced_data, 0, 0)
    print('Number of particles: ' + str(idx))  # total number of particles
    plt.hist(Ages, bins=30)
    plt.xlabel('Particle age (frames)')
    plt.ylabel('Number of particles')
    ind = np.lexsort((Reduced_data[:, 0], Reduced_data[:, 1]))
    # print(type(ind))
    Reduced_data[ind]
    # print(Reduced_data)
    print('Long traces: ' + str(Hit_count))
    thefile = open(trace_file_path + trace_file_name, 'w')
    for item in Reduced_data:
        thefile.write('{},{},{},{},{}\n'.format(
            int(item[0]), int(item[1]), item[2], item[3], item[4]))
    return Reduced_data


def cutData(data, xmin=None, xmax=None, ymin=None, ymax=None, zmin=None,
            zmax=None, tmin=None, tmax=None):
    slice_data = data
    if xmin is not None:
        slice_data = slice_data[slice_data[:, 2] > xmin, :]
    if xmax is not None:
        slice_data = slice_data[slice_data[:, 2] < xmax, :]
    if ymin is not None:
        slice_data = slice_data[slice_data[:, 3] > ymin, :]
    if ymax is not None:
        slice_data = slice_data[slice_data[:, 3] < ymax, :]
    if zmin is not None:
        slice_data = slice_data[slice_data[:, 4] > zmin, :]
    if zmax is not None:
        slice_data = slice_data[slice_data[:, 4] < zmax, :]
    if tmin is not None:
        slice_data = slice_data[slice_data[:, 1] > tmin, :]
    if tmax is not None:
        slice_data = slice_data[slice_data[:, 1] < tmax, :]
    return slice_data


# def plot3d(data):
#     plotly.offline.init_notebook_mode()
#     trace0 = Scatter3d(
#         x=data[:, 2],
#         y=data[:, 3],
#         z=data[:, 4],
#         marker=Marker(color=data[:, 1],
#                       colorscale='Portland',
#                       colorbar=dict(
#                           title='Time (frame number)'),
#                       size=1),
#         mode='markers')

#     data = Data([trace0])

#     layout = Layout(
#         margin=dict(
#             l=0,
#             r=0,
#             b=0,
#             t=0))
#     fig = Figure(data=data, layout=layout)
#     plotly.offline.iplot(fig)

def plotSlice(data, vmin=1, vmax=None, xdim=2, ydim=3, cdim=1, size=4,
              colorScale='viridis'):
    viridis = plt.cm.get_cmap(colorScale)
    try:
        if vmax is None:
            color_norm = colors.Normalize(
                vmin=min(data[:, cdim]), vmax=max(data[:, cdim]))
            vmin = min(data[:, cdim])
            vmax = max(data[:, cdim])
        else:
            color_norm = colors.Normalize(vmin=vmin, vmax=vmax)
        scalar_map = cm.ScalarMappable(norm=color_norm, cmap=viridis)
        color_map = scalar_map.to_rgba(data[:, cdim])
    except ValueError:
        print('Value error, num beads = {}'.format(len(data)))

    fig = plt.scatter(data[:, xdim], data[:, ydim],
                      c=data[:, cdim], vmin=vmin, vmax=vmax, cmap=viridis,
                      edgecolors='None', s=size)
    lab = {2: 'X', 3: 'Y', 4: 'Z'}
    plt.xlabel('{} ($\mu$m)'.format(lab.get(xdim)))
    plt.ylabel('{} ($\mu$m)'.format(lab.get(ydim)))
    cbar = plt.colorbar(fig)
    clab = {1: "Time (s)", 2: 'X $\mu$m', 3: 'Y $\mu$m', 4: 'Z $\mu$m'}
    cbar.set_label('{}'.format(clab.get(cdim)))


def loadData(path, name, tStep=1):
    try:
        data = []
        data = np.loadtxt(
            open('{}{}'.format(path, name), 'rb'),
            delimiter=',', skiprows=0)
        data[:, 1] = data[:, 1] * tStep  # Scale time per acquisition period.
        return data
    except FileNotFoundError:
        print('Not found: ', name)
        return 'File not found'
    return


def plotAndSave(path, name, nickname='', zmin=None, zmax=None, zbottom=0,
                tStep=3, xdim=2, ydim=4, cdim=1, xmin=None, xmax=None,
                tmax=None):
    """
    Load trace data file, apply slices, plot slices, and save the figure.
    """
    data = loadData(path, name, tStep)
    data[:, 4] = data[:, 4] - zbottom  # Apply z offset
    plt.title(name.split('_run')[0])
    t1 = cutData(data, tmax=tmax)  # , zmin=zmin, zmax=zmax)
    try:
        tmax = max(t1[:, 1])
    except ValueError:
        print('ValueError finding tmax', name, nickname)
    plotSlice(t1, vmax=tmax, xdim=xdim, ydim=ydim, cdim=cdim,
              colorScale='viridis')
    # plt.xlim(0, 1400)
    plt.ylim(zmin, zmax)
    plt.xlim(xmin, xmax)
    name = name.split('.')[0]
    plt.savefig('{}{}{}.png'.format(path, name, nickname))
    # plt.close()
    return


def getIndTrace(data):
    """ Generator to iterate through individual traces. """
    for i in set(data[:, 0]):
        trace = data[data[:, 0] == i, :]  # Get individual trace
        yield trace


def applyLowess(data):
    """
    Apply loess filter to x, y, and z.
    Take time derivative of position to get speed over time.
    Return array of times and speeds.
    """
    # Apply lowess filter.
    for idx, trace in enumerate(getIndTrace(data)):
        smooth_xts = trace.copy()
        trace_length = len(trace)
        for dim in [2, 3, 4]:
            dds = lowess(
                trace[:, dim], trace[:, 1], frac=100 / trace_length)
            smooth_xts[:, dim] = dds[:, 1]
        if idx == 0:
            smooth_xs = smooth_xts
        else:
            smooth_xs = np.append(smooth_xs, smooth_xts, 0)
    return smooth_xs


def getSpeeds(data, tStep):
    smooth_xs = applyLowess(data)
    speeds = []
    for idx, trace in enumerate(getIndTrace(smooth_xs)):
        dtrace = {
            0: trace[:, 0],
            1: trace[:, 1]}
        for dim in [2, 3, 4]:
            dtrace[dim] = np.gradient(trace[:, dim], tStep)
            # Calculate vectors
        dtrace['Speed (\mum/sec)'] = np.sqrt(
            (dtrace[2])**2 + (dtrace[3])**2 + (dtrace[4])**2)
        # Calculate magnitudes of vectors
        speeds.append(dtrace)
    return speeds


def integrateSpeeds(data, tStep):
    speeds = getSpeeds(data, tStep)
    dist = []
    for trace in speeds:
        traceDist = np.sum(trace['Speed (\mum/sec)'] * tStep)
        dist.append(traceDist)
    return dist


def filterTraces(data, minTime, tStep):
    """ Remove traces that are too short. """
    # print('Original dataset length: ', len(data))
    # print(data)
    cuts = 0
    hits = 0
    for trace in getIndTrace(data):
        if len(trace) * tStep >= minTime:
            hits += 1
            try:
                filterData = np.append(filterData, trace, 0)
            except NameError:
                filterData = trace
        else:
            cuts += 1
    print('{}hits, {} cuts'.format(hits, cuts))
    if hits == 0:
        return None
    else:
        return filterData


def collectAllSpeeds(data, tStep):
    speeds = getSpeeds(data, tStep)
    allSpeeds = []
    for trace in speeds:
        allSpeeds = np.append(allSpeeds, trace['Speed (\mum/sec)'])
    return allSpeeds
