"""
20190815
Author: Cameron Yamanishi

One-time code to generate figures about microscope calibration for thesis
defense.

"""

import stigmaticMicroscope
from matplotlib import pyplot as plt
import os

zFilePath = 'D:/201904 Mint CY/0805 zStack/images/20degwetrollbackcropped/'
zFiles = [i for i in os.listdir(zFilePath) if i.endswith('.tif')]
print(zFiles)


# Set parameters
calibration = stigmaticMicroscope.Calibration(filePath=zFilePath)
# Adjust z step size
calibration.stepSize = 200 * 10 / 360  # micron/rotation * deg/360

threshold = 80
span = 25
calibration.minParticleLength = 10
calibration.intensityThreshold = threshold
calibration.span = span

# calibration.calibrate(plots=True)
# raise NameError
print('thresh {}, span {}'.format(threshold, span))
calibration.calibrate(plots=True)
# plt.subplots_adjust(wspace=0.5)