README.txt

Author: Cameron Yamanishi
Module: Functions to track particles using stigmatic microscopy.