import matplotlib.pyplot as plt
import cv2

x = [1, 2, 3]
y = [1, 1, .9]
print('plotting...')
plt.bar(x, y)
plt.show()
