"""
20190806
Cameron Yamanishi
Single-use code to generate directories for handling in FIJI
to convert images from .nd2 to 8-bit .tif.
"""

import os

directory = 'E:/201904 Mint CY/0719 Flow tracking ELISA Mint/'
subDirs = [i for i in os.listdir(directory) if os.path.isdir(
    '{}{}'.format(directory, i))]
for subDir in subDirs:
    thirdDirs = [i for i in os.listdir('{}/{}'.format(
        directory, subDir)) if os.path.isdir(
        '{}/{}/{}'.format(directory, subDir, i))]
    for thirdDir in thirdDirs:
        stacks = [i for i in os.listdir('{}/{}/{}'.format(
            directory, subDir, thirdDir)) if i.endswith(
            '.nd2')]
        for stack in stacks:
            local = '{}/{}/{}/'.format(
                directory, subDir, thirdDir)
            stackName = os.path.splitext(stack)[0]
            if os.path.exists('{}{}'.format(local, stackName)):
                continue
            else:
                os.mkdir('{}{}'.format(local, stackName))
                print('Made dir', local, stackName)
